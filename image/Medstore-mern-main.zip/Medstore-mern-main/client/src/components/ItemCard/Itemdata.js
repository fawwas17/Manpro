

const Itemdata = {

    productData: [
        {
            id:1,
            img: "https://source.unsplash.com/100x100/?medicine,covid",
            title : "Cipla",
            desc:"Nice",
            price:34,
            details : "New Offer",
        },
        {
            id:2,
            img: "https://source.unsplash.com/100x100/?medicine,covid",
            title : "Cipla Lite",
            desc:"Nice One",
            price:104,
            details : "New Bonus Offer",
        },
        {
            id:3,
            img: "https://source.unsplash.com/100x100/?medicine,covid",
            title : "Cipla Pero",
            desc:"New",
            price:200,
            details : "15% off",
        },

    ]


}

export default Itemdata;