const userData = [
    {
        id: 1,
        name: "Medical E-Store",
        lati: 19.0760,
        long: 72.8777
    },
    {
        id: 2,
        name: "Medical",
        lati: 18.5204,
        long: 73.8567
    }
]
export default userData;