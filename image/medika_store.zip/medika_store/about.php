<!--
"Medika Store" adalah toko online alat kesehatan yang dikembangkan untuk keperluan akademis. Desain dan pengembangan oleh Achmad Sirajul Fahmi. (c) 2024 Hak Cipta Dilindungi.
-->
<?php

include "core.php";

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Tentang Kami</title>
	<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="page">
		<div class="header">
			<?php

			showHeading();

			?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php

				mainMenu();

				?>
			</div>
			<div class="contents">
				<h2>Tentang Medika Store</h2>
				<p>Medika Store adalah toko online alat kesehatan yang dikembangkan untuk keperluan akademis, dengan
					tujuan untuk menyediakan akses yang mudah dan cepat kepada pelanggan kami untuk mendapatkan berbagai
					jenis alat kesehatan yang berkualitas tinggi dan harga yang kompetitif.</p>
				<p>Kami berkomitmen untuk memberikan pelayanan yang terbaik kepada pelanggan kami, dengan menyediakan
					produk yang aman, efektif, dan mudah digunakan. Kami juga berusaha untuk memastikan bahwa semua
					produk yang kami jual telah memenuhi standar kualitas yang tinggi dan telah diuji secara menyeluruh
					sebelum dijual.</p>
				<p>Medika Store juga berusaha untuk menjadi toko online alat kesehatan yang paling terpercaya dan
					dipercaya oleh pelanggan kami. Kami berusaha untuk membangun hubungan yang baik dengan pelanggan
					kami dan memberikan pelayanan yang memuaskan.</p>
			</div>
		</div>
		<div class="footer">
			<?php

			showFooter();

			?>
		</div>
	</div>
</body>

</html>