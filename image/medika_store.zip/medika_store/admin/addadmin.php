<!--
"Medika Store" adalah toko online alat kesehatan yang dikembangkan untuk keperluan akademis. Desain dan pengembangan oleh Achmad Sirajul Fahmi. (c) 2024 Hak Cipta Dilindungi.
-->
<?php

include "../core.php";
include "../dbconnection.php";

//jika pengguna tidak login, redirect ke halaman login
if (!isset($_SESSION['aid'])) {
  header("Location: login.php");
}

?>
<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Tambah Admin</title>
  <link href="../styles/style.css" rel="stylesheet" type="text/css" />
  <script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
  <div class="page">
    <div class="header">
      <?php

      showHeading();

      ?>
    </div>
    <div class="wrapper">
      <div class="navigation">
        <?php

        adminMenu();

        ?>
      </div>
      <div class="contents">
        <h2>Tambah Admin</h2>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
          $username = validateInput($_POST['txtName']);
          $address = validateInput($_POST['txtAddress']);
          $email = validateInput($_POST['txtEmail']);
          $password = validateInput($_POST['txtPassword']);

          $stmt = $con->prepare("INSERT INTO tbladmin (username, address, email, password) VALUES (?, ?, ?, ?)");
          $stmt->bind_param("ssss", $username, $address, $email, md5($password)); //password hash md5
          if ($stmt->execute()) {
            echo "Admin berhasil ditambahkan!<br/>";
          } else {
            echo "Gagal menambahkan admin<br/>";
          }
        }
        ?>
        <form id="form1" name="form1" method="post" action="addadmin.php" onsubmit="return validateRegister()">
          <p>
            <label>Nama:
              <br />
              <input name="txtName" type="text" id="txtName" />
            </label>
          </p>
          <p>
            <label>Alamat:<br />
              <input name="txtAddress" type="text" id="txtAddress" />
            </label>
          </p>
          <p>
            <label>Email:
              <br />
              <input name="txtEmail" type="text" id="txtEmail" />
            </label>
          </p>
          <p>
            <label>Password: <br />
              <input name="txtPassword" type="password" id="txtPassword" />
            </label>
          </p>
          <p>
            <label>Konfirmasi Password:
              <br />
              <input name="txtConfPassword" type="password" id="txtConfPassword" />
            </label>
          </p>
          <p>
            <input type="submit" name="Submit" value="Submit" />
          </p>
        </form>
      </div>
    </div>
    <div class="footer">
      <?php

      showFooter();

      ?>
    </div>
  </div>
</body>

</html>