<?php

include "../core.php";
include "../dbconnection.php";

// Redirect to login if not logged in
if (!isset($_SESSION['aid'])) {
    header("Location: login.php");
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $categoryname = validateInput($_POST['txtCategoryName']);

    // Prepare and execute the insert query
    $stmt = $con->prepare("INSERT INTO tblcategory (categoryname) VALUES (?)");
    $stmt->bind_param("s", $categoryname);

    if ($stmt->execute()) {
        $success = "Kategori berhasil ditambahkan!";
    } else {
        $error = "Gagal menambahkan kategori.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Tambah Kategori</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css" />
    <script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
    <div class="page">
        <div class="header">
            <?php showHeading(); ?>
        </div>
        <div class="wrapper">
            <div class="navigation">
                <?php adminMenu(); ?>
            </div>
            <div class="contents">
                <h2>Tambah Kategori</h2>
                <?php if (isset($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php elseif (isset($success)): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                <form action="addcategory.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
                    <p>
                        <label>Nama Kategori:<br />
                            <input name="txtCategoryName" type="text" id="txtCategoryName" size="50" maxlength="100"
                                required />
                        </label>
                    </p>
                    <p>
                        <button type="submit" name="Submit">Tambah Kategori</button>
                        <a href="categories.php">Kembali</a>
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php showFooter(); ?>
        </div>
    </div>
</body>

</html>