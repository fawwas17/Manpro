<?php

include "../core.php";
include "../dbconnection.php";

// Redirect to login if not logged in
if (!isset($_SESSION['aid'])) {
    header("Location: login.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Kategori</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css" />
    <script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
    <div class="page">
        <div class="header">
            <?php showHeading(); ?>
        </div>
        <div class="wrapper">
            <div class="navigation">
                <?php adminMenu(); ?>
            </div>
            <div class="contents">
                <h2>Kategori</h2>
                <?php

                // Delete category
                if (isset($_GET['deletecid'])) {
                    $stmtdelete = $con->prepare("DELETE FROM tblcategory WHERE cid=?");
                    $stmtdelete->bind_param("i", validateInput($_GET['deletecid']));
                    if ($stmtdelete->execute()) {
                        echo "Kategori berhasil dihapus!<br/>";
                    } else {
                        echo "Error menghapus kategori<br/>";
                    }
                }

                ?>
                <table width="100%" border="1" cellspacing="0" cellpadding="0">
                    <tr>
                        <th scope="col">ID Kategori</th>
                        <th scope="col">Nama Kategori</th>
                        <th scope="col" colspan="2">Opsi</th>
                    </tr>
                    <?php

                    // Display categories
                    $sql = "SELECT * FROM tblcategory ORDER BY cid DESC";
                    $result = $con->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['cid'] . "</td>";
                            echo "<td>" . $row['categoryname'] . "</td>";
                            echo "<td><a href=\"editcategory.php?editcid=" . $row['cid'] . "\">Edit</a></td>";
                            echo "<td><a href=\"categories.php?deletecid=" . $row['cid'] . "\" onclick=\"return confirm('Apakah Anda yakin ingin menghapus kategori ini?')\">Hapus</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan=\"5\">Tidak ada kategori!</td></tr>";
                    }

                    ?>
                </table>

            </div>
        </div>
        <div class="footer">
            <?php showFooter(); ?>
        </div>
    </div>
</body>

</html>