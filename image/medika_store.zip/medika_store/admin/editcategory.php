<?php

include "../core.php";
include "../dbconnection.php";

// Redirect to login if not logged in
if (!isset($_SESSION['aid'])) {
    header("Location: login.php");
}

if (!isset($_GET['editcid'])) {
    header("Location: categories.php");
}

$cid = validateInput($_GET['editcid']);
$category = [];

// Fetch the category details
$catSql = "SELECT * FROM tblcategory WHERE cid = ?";
$stmt = $con->prepare($catSql);
$stmt->bind_param("i", $cid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $category = $result->fetch_assoc();
} else {
    header("Location: categories.php");
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $categoryname = validateInput($_POST['txtCategoryName']);

    // Prepare and execute the update query
    $stmt = $con->prepare("UPDATE tblcategory SET categoryname=?, WHERE cid=?");
    $stmt->bind_param("ssi", $categoryname, $cid);

    if ($stmt->execute()) {
        $success = "Kategori berhasil diperbarui!";
    } else {
        $error = "Gagal memperbarui kategori.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Kategori</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css" />
    <script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
    <div class="page">
        <div class="header">
            <?php showHeading(); ?>
        </div>
        <div class="wrapper">
            <div class="navigation">
                <?php adminMenu(); ?>
            </div>
            <div class="contents">
                <h2>Edit Kategori</h2>
                <?php if (isset($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php elseif (isset($success)): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                <form action="editcategory.php?editcid=<?php echo $cid; ?>" method="post" enctype="multipart/form-data"
                    name="form1" id="form1">
                    <p>
                        <label>Nama Kategori:<br />
                            <input name="txtCategoryName" type="text" id="txtCategoryName"
                                value="<?php echo $category['categoryname']; ?>" size="50" maxlength="100" required />
                        </label>
                    </p>
                    <p>
                    </p>
                    <p>
                        <button type="submit" name="Submit">Perbarui Kategori</button>
                        <a href="categories.php">Kembali</a>
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php showFooter(); ?>
        </div>
    </div>
</body>

</html>