<?php

include "../core.php";
include "../dbconnection.php";

//jika pengguna tidak login, redirect ke halaman login
if (!isset($_SESSION['aid'])) {
	header("Location: login.php");
}

if (!isset($_GET['editpid'])) {
	header("Location: products.php");
}

$pid = validateInput($_GET['editpid']);
$product = [];
$categories = [];

// Fetch the product details
$productSql = "SELECT * FROM tblproduct WHERE pid = ?";
$stmt = $con->prepare($productSql);
$stmt->bind_param("i", $pid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
	$product = $result->fetch_assoc();
} else {
	header("Location: products.php");
}

// Fetch categories for dropdown
$catSql = "SELECT * FROM tblcategory";
$catResult = $con->query($catSql);
if ($catResult->num_rows > 0) {
	while ($catRow = $catResult->fetch_assoc()) {
		$categories[] = $catRow;
	}
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
	// Sanitize inputs and validate
	$productname = validateInput($_POST['txtName']);
	$description = validateInput($_POST['txtDescription']);
	$price = validateInput($_POST['txtPrice']);
	$cid = validateInput($_POST['txtCategory']);

	// Prepare and execute the update query
	$stmt = $con->prepare("UPDATE tblproduct SET productname=?, description=?, price=?, category_id=? WHERE pid=?");
	$stmt->bind_param("ssdii", $productname, $description, $price, $cid, $pid);

	if ($stmt->execute()) {
		$success = "Produk berhasil diperbarui!";
	} else {
		$error = "Gagal memperbarui produk.";
	}
}

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Edit Produk</title>
	<link href="../styles/style.css" rel="stylesheet" type="text/css" />
	<script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
	<div class="page">
		<div class="header">
			<?php showHeading(); ?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php adminMenu(); ?>
			</div>
			<div class="contents">
				<h2>Edit Produk</h2>
				<?php if (isset($error)): ?>
					<div class="error-message"><?php echo $error; ?></div>
				<?php elseif (isset($success)): ?>
					<div class="success-message"><?php echo $success; ?></div>
				<?php endif; ?>
				<form action="editproduct.php?editpid=<?php echo $pid; ?>" method="post" enctype="multipart/form-data"
					name="form1" id="form1" onsubmit="return validateAddProduct()">
					<p>
						<label>Nama Produk:<br />
							<input name="txtName" type="text" id="txtName"
								value="<?php echo $product['productname']; ?>" size="50" maxlength="200" required />
						</label>
					</p>
					<p>
						<label>Deskripsi Produk:<br />
							<textarea name="txtDescription" id="txtDescription" rows="10" cols="50"
								required><?php echo $product['description']; ?></textarea>
						</label>
					</p>
					<p>
						<label>Harga:<br />
							<input name="txtPrice" type="number" id="txtPrice" value="<?php echo $product['price']; ?>"
								required />
						</label>
					</p>
					<p>
						<label>Kategori:<br />
							<select name="txtCategory" required>
								<option value="">Pilih Kategori</option>
								<?php foreach ($categories as $category): ?>
									<option value="<?php echo $category['cid']; ?>" <?php echo ($category['cid'] == $product['category_id']) ? 'selected' : ''; ?>>
										<?php echo $category['categoryname']; ?>
									</option>
								<?php endforeach; ?>
							</select>
						</label>
					</p>
					<p>
						<button type="submit" name="Submit">Perbarui Produk</button>
						<a href="products.php">Kembali</a>
					</p>
				</form>
			</div>
		</div>
		<div class="footer">
			<?php showFooter(); ?>
		</div>
	</div>
</body>

</html>