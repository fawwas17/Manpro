<?php

include "../core.php";
include "../dbconnection.php";

// Redirect to login if the user is not logged in
if (!isset($_SESSION['aid'])) {
	header("Location: login.php");
	exit();
}

// Function to fetch counts and totals
function fetchCount($con, $query)
{
	$result = $con->query($query);
	return $result->fetch_assoc()['num'];
}

// Function to fetch total transactions
function fetchTotalTransactions($con)
{
	$sql = "SELECT SUM(price) AS total_transactions FROM tblorder WHERE valid = 'Yes'";
	$result = $con->query($sql);
	$total = $result->fetch_assoc()['total_transactions'];

	// Check if total is null or zero
	if ($total === null || $total == 0) {
		return "Belum ada catatan";
	} else {
		return "Rp. " . number_format($total, 2, ',', '.');
	}
}

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Beranda</title>
	<link href="../styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="page">
		<header class="header">
			<?php showHeading(); ?>
		</header>
		<div class="wrapper">
			<nav class="navigation">
				<?php adminMenu(); ?>
			</nav>
			<main class="contents">
				<h2>CP Admin</h2>
				<section class="statistics">
					<p>Total pengguna: <?= fetchCount($con, "SELECT COUNT(*) AS num FROM tbluser"); ?></p>
					<p>Total admin: <?= fetchCount($con, "SELECT COUNT(*) AS num FROM tbladmin"); ?></p>
					<p>Total produk: <?= fetchCount($con, "SELECT COUNT(*) AS num FROM tblproduct"); ?></p>
					<p>Total pesanan: <?= fetchCount($con, "SELECT COUNT(*) AS num FROM tblorder"); ?></p>
					<p>Total item pesanan: <?= fetchCount($con, "SELECT COUNT(*) AS num FROM tblorderitem"); ?></p>
					<p>Total admin: <?= fetchCount($con, "SELECT COUNT(*) AS num FROM tbladmin"); ?></p>
					<p>Total transaksi: <?= fetchTotalTransactions($con); ?></p>
				</section>
			</main>
		</div>
		<footer class="footer">
			<?php showFooter(); ?>
		</footer>
	</div>
</body>

</html>