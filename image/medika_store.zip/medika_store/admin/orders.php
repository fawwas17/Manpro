<?php
require_once "../core.php";
include "../dbconnection.php";
include "laporan.php";

// jika pengguna tidak login, redirect ke halaman login
if (!isset($_SESSION['aid'])) {
	header("Location: login.php");
}

// Include email sending function
include "./send_email.php";

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Pesanan</title>
	<link href="../styles/style.css" rel="stylesheet" type="text/css" />
	<script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
	<div class="page">
		<div class="header">
			<?php showHeading(); ?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php adminMenu(); ?>
			</div>
			<div class="contents">
				<h2>Pesanan</h2>
				<?php
				// validasi pesanan
				if (isset($_GET['validateoid'])) {
					$oid = validateInput($_GET['validateoid']);

					$stmtvalidate = $con->prepare("UPDATE tblorder SET valid='Yes' WHERE oid=?");
					$stmtvalidate->bind_param("i", $oid);

					if ($stmtvalidate->execute()) {
						echo "Pesanan berhasil divalidasi!<br/>";

						// Query for user email
						$stmtEmail = $con->prepare("SELECT tbluser.email, tbluser.username FROM tbluser INNER JOIN tblorder ON tbluser.uid=tblorder.uid WHERE tblorder.oid=?");
						$stmtEmail->bind_param("i", $oid);
						$stmtEmail->execute();
						$result = $stmtEmail->get_result();
						$row = $result->fetch_assoc();

						$userEmail = $row['email'];
						$userName = $row['username'];

						// Generate laporan dan mengirimkan email
						$pdfContent = generateLaporanPdf($oid, true);

						if (sendEmailWithAttachment(
							$userEmail, 
							"Pesanan - " . $userName . " Berhasil Dikonfirmasi!", 
							"Pesanan Anda telah dikonfirmasi, berikut merupakan lampiran pesanan Anda:", 
							$pdfContent, 
							"laporan_$oid.pdf"
						)) {
							echo "Detail pesanan terkirim ke email pengguna: " . $userEmail . "<br/>";
						} else {
							echo "Gagal mengirim email laporan!<br/>";
						}
					} else {
						echo "Error memvalidasi pesanan<br/>";
					}
				}
				?>

				<table width="100%" border="1" cellspacing="0" cellpadding="0">
					<tr>
						<th scope="col">ID <br>Pesanan </th>
						<th scope="col">ID <br>Pengguna </th>
						<th scope="col">Waktu</th>
						<th scope="col">Metode <br>Pembayaran </th>
						<th scope="col">Alamat <br>Pengiriman </th>
						<th scope="col">Total</th>
						<th scope="col">Validasi</th>
						<th scope="col" colspan="3">Opsi</th>
					</tr>
					<?php
					// tampilkan pesanan
					$sql = "SELECT * FROM tblorder ORDER BY oid DESC";
					$result = $con->query($sql);
					if ($result->num_rows > 0) {
						while ($row = $result->fetch_assoc()) {
							echo "<tr>";
							echo "<td>" . $row['oid'] . "</td>";
							echo "<td>" . $row['uid'] . "</td>";
							echo "<td>" . $row['time'] . "</td>";

							$payment_method_display = ($row['payment_method'] === 'Prepaid') ? 'Debit' : 'COD';
							echo "<td>" . htmlspecialchars($payment_method_display) . "</td>";

							echo "<td>" . $row['address'] . "</td>";
							echo "<td>" . number_format($row['price'], 0, ',', '.') . "</td>";
							echo "<td>" . $row['valid'] . "</td>";
							echo "<td><a href=\"orderitems.php?oid=" . $row['oid'] . "\">Detail</a></td>";

							if ($row['valid'] !== 'Yes') {
								echo "<td><a href=\"orders.php?validateoid=" . $row['oid'] . "\" onclick=\"return confirmValidate()\">Validasi</a></td>";
							} else {
								echo "<td><a href=\"laporan_cetak.php?oid=" . $row['oid'] . "\">Cetak</a></td>";
							}

							echo "</tr>";
						}
					} else {
						echo "<tr><td colspan=\"10\">Tidak ada pesanan!</td></tr>";
					}
					?>
				</table>
			</div>
		</div>
		<div class="footer">
			<?php showFooter(); ?>
		</div>
	</div>
</body>

</html>