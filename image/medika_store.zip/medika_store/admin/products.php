<?php

include "../core.php";
include "../dbconnection.php";

//jika pengguna tidak login, redirect ke halaman login
if (!isset($_SESSION['aid'])) {
	header("Location: login.php");
}

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Produk</title>
	<link href="../styles/style.css" rel="stylesheet" type="text/css" />
	<script src="../js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
	<div class="page">
		<div class="header">
			<?php showHeading(); ?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php adminMenu(); ?>
			</div>
			<div class="contents">
				<h2>Produk</h2>
				<?php

				//hapus produk
				if (isset($_GET['deletepid']) && isset($_GET['imgurl'])) {
					$file = "../" . validateInput($_GET['imgurl']);
					$stmtdelete = $con->prepare("DELETE FROM tblproduct WHERE pid=?");
					$stmtdelete->bind_param("i", validateInput($_GET['deletepid']));
					if ($stmtdelete->execute() && unlink($file)) {
						echo "Produk berhasil dihapus!<br/>";
					} else {
						echo "Error menghapus produk<br/>";
					}
				}

				?>
				<table width="100%" border="1" cellspacing="0" cellpadding="0">
					<tr>
						<th scope="col">ID Produk</th>
						<th scope="col">Nama</th>
						<th scope="col">Deskripsi</th>
						<th scope="col">Harga</th>
						<th scope="col">Kategori</th>
						<th scope="col" colspan="2">Opsi</th>
					</tr>
					<?php

					//tampilkan produk
					$sql = "SELECT p.*, c.categoryname FROM tblproduct p LEFT JOIN tblcategory c ON p.category_id = c.cid ORDER BY p.pid DESC";
					$result = $con->query($sql);
					if ($result->num_rows > 0) {
						while ($row = $result->fetch_assoc()) {
							echo "<tr>";
							echo "<td>" . $row['pid'] . "</td>";
							echo "<td>" . $row['productname'] . "</td>";
							echo "<td>" . $row['description'] . "</td>";
							echo "<td>Rp. " . number_format($row['price'], 2, ',', '.') . "</td>";
							echo "<td>" . $row['categoryname'] . "</td>";
							echo "<td><a href=\"products.php?deletepid=" . $row['pid'] . "&imgurl=" . $row['imgurl'] . "\" onclick=\"return confirmDelete()\">Hapus</a></td>";
							echo "<td><a href=\"editproduct.php?editpid=" . $row['pid'] . "\">Edit</a></td>";
							echo "</tr>";
						}
					} else {
						echo "<tr><td colspan=\"7\">Tidak ada record!</td></tr>";
					}

					?>
				</table>

			</div>
		</div>
		<div class="footer">
			<?php showFooter(); ?>
		</div>
	</div>
</body>

</html>