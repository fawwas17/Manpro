<?php
include "core.php";
include "dbconnection.php";

// Redirect to homepage if user is not logged in
if (!isset($_SESSION['uid'])) {
	header("Location: index.php");
	exit;
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Keranjang Belanja</title>
	<link href="styles/style.css" rel="stylesheet" type="text/css" />
	<script src="js/myscript.js" language="javascript" type="text/javascript"></script>
	<script type="text/javascript">
		function togglePaymentFields() {
			const paymentMethod = document.querySelector('select[name="payment_method"]').value;
			const cardFields = document.getElementById('cardFields');

			if (paymentMethod === 'postpaid') {
				cardFields.style.display = 'none';
			} else {
				cardFields.style.display = 'block';
			}
		}

		window.onload = function () {
			togglePaymentFields();
		}

		function validateOrder() {
			const paymentMethod = document.querySelector('select[name="payment_method"]').value;
			const cardNumber = document.getElementById('txtCredit').value;
			const bankName = document.getElementById('txtBank').value;

			if (paymentMethod === 'prepaid' && (cardNumber === '' || bankName === '')) {
				alert("Please fill out credit card and bank fields for prepaid payment.");
				return false;
			}
			return true;
		}
	</script>
</head>

<body>
	<div class="page">
		<div class="header">
			<?php showHeading(); ?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php mainMenu(); ?>
			</div>
			<div class="contents">
				<h2>Keranjang Belanja</h2>

				<?php
				// Handling quantity increase and decrease
				if (isset($_GET['addqty'])) {
					$cdid = validateInput($_GET['addqty']);
					$stmt = $con->prepare("UPDATE tblcartdetail SET qty = qty + 1 WHERE cdid = ?");
					$stmt->bind_param("i", $cdid);
					$stmt->execute();
				}

				if (isset($_GET['reduceqty'])) {
					$cdid = validateInput($_GET['reduceqty']);
					$stmt = $con->prepare("UPDATE tblcartdetail SET qty = qty - 1 WHERE cdid = ? AND qty > 1");
					$stmt->bind_param("i", $cdid);
					$stmt->execute();
				}

				// Handling item deletion
				if (isset($_GET['deleteid'])) {
					$deleteid = validateInput($_GET['deleteid']);
					$stmt = $con->prepare("DELETE FROM tblcartdetail WHERE cdid = ?");
					$stmt->bind_param("i", $deleteid);
					if ($stmt->execute()) {
						echo "<p>Item dihapus dari keranjang</p>";
					} else {
						echo "<p>Error menghapus item</p>";
					}
				}

				// SQL query to get cart details
				$sql = "SELECT tblproduct.productname, tblproduct.description, tblproduct.price, tblcartdetail.cdid, tblcartdetail.qty 
                        FROM tblproduct 
                        INNER JOIN tblcartdetail ON tblproduct.pid = tblcartdetail.pid 
                        INNER JOIN tblcart ON tblcartdetail.cid = tblcart.cid 
                        WHERE tblcart.uid = ?";

				$stmt = $con->prepare($sql);
				$stmt->bind_param("i", $_SESSION["uid"]);
				$stmt->execute();
				$result = $stmt->get_result();

				if ($result->num_rows > 0) {
					$totalAmount = 0;
					echo "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">";
					echo "<tr>
                            <th>Nama Produk</th>
                            <th>Deskripsi</th>
                            <th>Harga</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Aksi</th>
                          </tr>";

					while ($row = $result->fetch_assoc()) {
						$totalItem = $row['price'] * $row['qty'];
						$totalAmount += $totalItem;
						echo "<tr>
                                <td>" . htmlspecialchars($row['productname']) . "</td>
                                <td>" . htmlspecialchars($row['description']) . "</td>
                                <td>" . htmlspecialchars(number_format($row['price'], 0, ',', '.')) . "</td>
                                <td>" . htmlspecialchars($row['qty']) . "</td>
                                <td>Rp. " . htmlspecialchars(number_format($totalItem, 2, ',', '.')) . "</td>
                                <td>
                                    <a href=\"cart.php?addqty=" . $row['cdid'] . "\">Tambah</a> | 
                                    <a href=\"cart.php?reduceqty=" . $row['cdid'] . "\">Kurangi</a> | 
                                    <a href=\"cart.php?deleteid=" . $row['cdid'] . "\" onclick=\"return confirmDelete()\">Hapus</a>
                                </td>
                              </tr>";
					}
					echo "</table>";

					// Display total amount
					echo "<br/>Total belanja: Rp." . number_format($totalAmount, 2, ',', '.');

					// Payment form section
					echo "<br/><br/><form action=\"orders.php\" method=\"post\" onsubmit=\"return validateOrder()\">
                            <fieldset>
                                <legend>Detail Pemesanan</legend>
                                <p>
                                    <label>Alamat Pengiriman:<br/>
                                    <input id=\"txtAddress\" type=\"text\" name=\"txtAddress\" required /></label>
                                </p>
                                <p>
                                    <label>Metode Pembayaran:<br/>
                                    <select name=\"payment_method\" required onchange=\"togglePaymentFields()\">
                                        <option value=\"prepaid\">Bayar dengan Kartu Debit</option>
                                        <option value=\"postpaid\">COD</option>
                                    </select></label>
                                </p>
                                <div id=\"cardFields\">
                                    <p>
                                        <label>Nomor Kartu:<br/>
                                        <input id=\"txtCredit\" type=\"text\" name=\"txtCredit\" /></label>
                                    </p>
                                    <p>
                                        <label>Bank:<br/>
                                        <input id=\"txtBank\" type=\"text\" name=\"txtBank\" /></label>
                                    </p>
                                </div>
                                <input name=\"price\" type=\"hidden\" value=\"" . $totalAmount . "\" />
                                <input type=\"submit\" value=\"Checkout\" />
                            </fieldset>
                          </form>";
				} else {
					echo "<p>Tidak ada item di keranjang</p>";
				}
				?>
			</div>
		</div>
		<div class="footer">
			<?php showFooter(); ?>
		</div>
	</div>
</body>

</html>