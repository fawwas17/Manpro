<!--
"Medika Store" adalah toko online alat kesehatan yang dikembangkan untuk keperluan akademis. Desain dan pengembangan oleh Achmad Sirajul Fahmi. (c) 2024 Hak Cipta Dilindungi.
-->
<?php

include "core.php";

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Kontak Kami</title>
	<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="page">
		<div class="header">
			<?php

			showHeading();

			?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php

				mainMenu();

				?>
			</div>
			<div class="contents">
				<h2>Kontak Kami</h2>
				<p>Desain dan pengembangan oleh Achmad Sirajul Fahmi</p>
				<p>E-Mail: <a href="21081010266@student.upnjatim.ac.id">medikastore@services.id</a></p>
				<p>Web: <a href="www.medikastore.com" target="localhost/medika_store/index.php">www.medikastore.com</a>
				</p>
				<p>Alamat: Jl.Raya Rungkut Madya, Gunung Anyar, Surabaya</p>
				<p>No. Telepon: <a href="tel: +629519548585">+629519548585</a></p>
			</div>
		</div>
		<div class="footer">
			<?php

			showFooter();

			?>
		</div>
	</div>
</body>

</html>