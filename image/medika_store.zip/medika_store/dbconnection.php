<?php

//update your database connection details here
$hostname = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "medika_store_db";

$con = new mysqli($hostname, $dbuser, $dbpass, $dbname);

if ($con->connect_error) {
    die("Error connect to db");
}

?>