<?php
include "core.php";
include "dbconnection.php";
?>
<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Medika Store</title>
  <link href="styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <div class="page">
    <div class="header">
      <?php showHeading(); ?>
    </div>
    <div class="wrapper">
      <div class="navigation">
        <?php mainMenu(); ?>
      </div>
      <div class="contents">
        <h2>Selamat Datang di Medika Store!</h2>
        <p>Kami menyediakan berbagai jenis peralatan kesehatan yang berkualitas tinggi dan harga yang kompetitif. Kami
          berkomitmen untuk memberikan pelayanan yang terbaik kepada pelanggan kami.</p>

        <!-- Dropdown filter for categories -->
        <form method="GET" action="">
          <label for="category">Filter berdasarkan kategori:</label>
          <select name="category" id="category" onchange="this.form.submit()">
            <option value="">Semua Kategori</option>
            <?php
            // Fetch categories from database
            $categoryResult = $con->query("SELECT * FROM tblcategory");
            while ($category = $categoryResult->fetch_assoc()) {
              // Check if the category is selected
              $selected = (isset($_GET['category']) && $_GET['category'] == $category['id']) ? 'selected' : '';
              echo "<option value=\"" . htmlspecialchars($category['id']) . "\" $selected>" . htmlspecialchars($category['categoryname']) . "</option>";
            }
            ?>
          </select>
          <p></p>
        </form>

        <table width="100%" border="1" cellpadding="5" cellspacing="0">
          <?php

          // Add item to the cart
          if (isset($_GET['pid'])) {
            if (isset($_SESSION['uid'])) {
              $pid = validateInput($_GET['pid']);

              // Check if the product already exists in the cart
              $stmt = $con->prepare("SELECT cid FROM tblcart WHERE uid = ?");
              $stmt->bind_param("i", $_SESSION['uid']);
              $stmt->execute();
              $result = $stmt->get_result();

              if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $cid = $row['cid'];

                // Check if the product already exists in the cart detail
                $stmt = $con->prepare("SELECT qty FROM tblcartdetail WHERE cid = ? AND pid = ?");
                $stmt->bind_param("ii", $cid, $pid);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                  // If exists, update the quantity
                  $row = $result->fetch_assoc();
                  $newQty = $row['qty'] + 1;
                  $stmt = $con->prepare("UPDATE tblcartdetail SET qty = ? WHERE cid = ? AND pid = ?");
                  $stmt->bind_param("iii", $newQty, $cid, $pid);
                  $stmt->execute();
                  echo "Berhasil menambahkan qty produk!<br/>";
                } else {
                  // If not exists, insert new item into tblcartdetail
                  $qty = 1;
                  $stmt = $con->prepare("INSERT INTO tblcartdetail (cid, pid, qty) VALUES (?, ?, ?)");
                  $stmt->bind_param("iii", $cid, $pid, $qty);
                  if ($stmt->execute()) {
                    echo "Produk telah ditambahkan pada keranjang!<br/>";
                  } else {
                    echo "Gagal Menambahkan Produk!<br/>";
                  }
                }
              } else {
                // If no cart exists for the user, create a new cart
                $stmt = $con->prepare("INSERT INTO tblcart (uid) VALUES (?)");
                $stmt->bind_param("i", $_SESSION['uid']);
                if ($stmt->execute()) {
                  $cid = $stmt->insert_id;

                  // Insert the product into tblcartdetail
                  $qty = 1;
                  $stmt = $con->prepare("INSERT INTO tblcartdetail (cid, pid, qty) VALUES (?, ?, ?)");
                  $stmt->bind_param("iii", $cid, $pid, $qty);
                  if ($stmt->execute()) {
                    echo "Berhasil menambahkan ke dalam keranjang!<br/>";
                  } else {
                    echo "Tidak dapat menambahkan keranjang<br/>";
                  }
                }
              }
            } else {
              echo "Anda harus login untuk menambahkan produk ini ke keranjang<br/>";
            }
          }

          // Pagination settings
          $page = null;
          $items_per_page = 4;
          if (isset($_GET["page"])) {
            $page = validateInput($_GET["page"]);
          }
          if ($page == "" || $page <= 0) {
            $page = 1;
          }

          // Get selected category
          $selected_category = isset($_GET['category']) ? validateInput($_GET['category']) : '';

          // Count products based on selected category
          $query = "SELECT COUNT(*) AS num FROM tblproduct";
          if ($selected_category) {
            $query .= " WHERE category_id = ?";
          }
          $stmt = $con->prepare($query);
          if ($selected_category) {
            $stmt->bind_param("i", $selected_category);
          }
          $stmt->execute();
          $row = $stmt->get_result()->fetch_assoc();
          $num_items = $row['num'];
          $num_pages = ceil($num_items / $items_per_page);
          if (($page > $num_pages) && $page != 1) {
            $page = $num_pages;
          }
          $limit_start = ($page - 1) * $items_per_page;

          // Display products based on selected category
          $sql = "SELECT * FROM tblproduct";
          if ($selected_category) {
            $sql .= " WHERE category_id = ?";
          }
          $sql .= " ORDER BY pid DESC LIMIT ?, ?";
          $stmt = $con->prepare($sql);
          if ($selected_category) {
            $stmt->bind_param("iii", $selected_category, $limit_start, $items_per_page);
          } else {
            $stmt->bind_param("ii", $limit_start, $items_per_page);
          }
          $stmt->execute();
          $result = $stmt->get_result();
          if ($result->num_rows > 0) {
            echo "<tr><th>Image</th><th>Nama Produk</th><th>Harga</th><th>Aksi</th></tr>";
            while ($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td width=\"100\"><img src=\"" . htmlspecialchars($row['imgurl']) . "\" height=\"100\" width=\"100\" /></td>";
              echo "<td><a href=\"product.php?pid=" . htmlspecialchars($row['pid']) . "\">" . htmlspecialchars($row['productname']) . "</a></td>";
              echo "<td>Rp. " . number_format($row['price'], 0, ',', '.') . "</td>";
              echo "<td><a href=\"index.php?pid=" . htmlspecialchars($row['pid']) . "&page=$page\">Add To Cart</a></td>";
              echo "</tr>";
            }
          } else {
            echo "<tr><td colspan=\"4\">Tidak ada produk yang tersedia</td></tr>";
          }
          ?>
        </table>

        <?php
        // Page navigation links
        if ($num_pages > 1) {
          echo "<p>";
          if ($page > 1) {
            $ppage = $page - 1;
            echo "<a href=\"index.php?page=$ppage\">Prev</a> ";
          }
          echo "$page/$num_pages";
          if ($page < $num_pages) {
            $npage = $page + 1;
            echo " <a href=\"index.php?page=$npage\">Next</a>";
          }
          echo "</p>";
        }
        ?>

      </div>
    </div>
    <div class="footer">
      <?php showFooter(); ?>
    </div>
  </div>
</body>

</html>