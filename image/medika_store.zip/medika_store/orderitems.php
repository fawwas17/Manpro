<!--
"Medika Store" adalah toko online alat kesehatan yang dikembangkan untuk keperluan akademis. Desain dan pengembangan oleh Achmad Sirajul Fahmi. (c) 2024 Hak Cipta Dilindungi.
-->
<?php

include "core.php";
include "dbconnection.php";

// Redirect to homepage if the user is not logged in
if (!isset($_SESSION['uid'])) {
	header("Location: index.php");
	exit;
}

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Item Pesanan</title>
	<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="page">
		<div class="header">
			<?php showHeading(); ?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php mainMenu(); ?>
			</div>
			<div class="contents">
				<h2>Item Pesanan</h2>
				<table width="100%" border="1" cellspacing="0" cellpadding="0">
					<tr>
						<th scope="col">Nama Produk</th>
						<th scope="col">Jumlah</th>
						<th scope="col">Sub Total</th>
					</tr>
					<?php

					// Display order items
					if (isset($_GET['oid'])) {
						$oid = validateInput($_GET['oid']);

						$sql = "SELECT tblproduct.productname, tblorderitem.qty, tblorderitem.item_price 
								FROM tblorderitem 
								INNER JOIN tblproduct ON tblorderitem.pid = tblproduct.pid 
								WHERE tblorderitem.oid = ? 
								ORDER BY tblorderitem.oiid DESC";

						$stmt = $con->prepare($sql);
						$stmt->bind_param("i", $oid);
						$stmt->execute();
						$result = $stmt->get_result();

						if ($result->num_rows > 0) {
							while ($row = $result->fetch_assoc()) {
								$quantity = (int) $row['qty'];
								$price = (float) $row['item_price'];
								$subtotal = $quantity * $price;

								echo "<tr>";
								echo "<td>" . htmlspecialchars($row['productname']) . "</td>";
								echo "<td>" . htmlspecialchars($quantity) . "</td>";
								echo "<td>Rp. " . htmlspecialchars(number_format($subtotal, 2)) . "</td>";
								echo "</tr>";
							}
						} else {
							echo "<tr><td colspan=\"3\">Tidak ada item pesanan!</td></tr>";
						}

						$stmt->close();
					} else {
						echo "<tr><td colspan=\"3\">ID Pesanan tidak tersedia!</td></tr>";
					}

					?>
				</table>
			</div>
		</div>
		<div class="footer">
			<?php showFooter(); ?>
		</div>
	</div>
</body>

</html>