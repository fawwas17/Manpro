<?php

include "core.php";
include "dbconnection.php";

// Redirect to homepage if user is not logged in
if (!isset($_SESSION['uid'])) {
	header("Location: index.php");
	exit;
}

?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Pesanan</title>
	<link href="styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="page">
		<div class="header">
			<?php showHeading(); ?>
		</div>
		<div class="wrapper">
			<div class="navigation">
				<?php mainMenu(); ?>
			</div>
			<div class="contents">
				<h2>Pesanan</h2>
				<?php

				// Adding a new order
				if ($_SERVER['REQUEST_METHOD'] == "POST") {
					$price = validateInput($_POST['price']);
					$address = validateInput($_POST['txtAddress']);
					$method = validateInput($_POST['payment_method']);
					$uid = $_SESSION['uid'];
					$acc_number = null;
					$bank = null;

					// Check if the payment method is prepaid
					if ($method === 'prepaid') {
						$acc_number = validateInput($_POST['txtCredit']);
						$bank = validateInput($_POST['txtBank']);
					}

					// Start transaction
					$con->begin_transaction();

					try {
						// Add a new order record
						$stmtorder = $con->prepare("INSERT INTO tblorder (price, acc_number, address, bank, payment_method, uid) VALUES (?, ?, ?, ?, ?, ?)");
						$stmtorder->bind_param("dssssi", $price, $acc_number, $address, $bank, $method, $uid);
						$stmtorder->execute();
						$lastoid = $stmtorder->insert_id;

						// Add cart items to tblorderitem
						$sql = "SELECT * FROM tblcartdetail WHERE cid = (SELECT cid FROM tblcart WHERE uid = ?)";
						$stmtcart = $con->prepare($sql);
						$stmtcart->bind_param("i", $uid);
						$stmtcart->execute();
						$result = $stmtcart->get_result();

						while ($row = $result->fetch_assoc()) {
							$pid = $row['pid'];
							$qty = $row['qty'];
							$item_price = getItemPrice($pid); // Helper function to get product price
				
							$stmtorderitem = $con->prepare("INSERT INTO tblorderitem (pid, oid, uid, qty, item_price) VALUES (?, ?, ?, ?, ?)");
							$stmtorderitem->bind_param("iiiii", $pid, $lastoid, $uid, $qty, $item_price);
							$stmtorderitem->execute();
						}

						// Clear the cart
						$stmt_clearcart = $con->prepare("DELETE FROM tblcart WHERE uid = ?");
						$stmt_clearcart->bind_param("i", $uid);
						$stmt_clearcart->execute();

						// Commit transaction
						$con->commit();
						echo "<p>Pesanan berhasil dibuat!</p>";
					} catch (Exception $e) {
						$con->rollback();
						echo "<p>Error membuat pesanan: " . $e->getMessage() . "</p>";
					}
				}

				// Display existing orders for the logged-in user
				$sql = "SELECT oid, time, price, payment_method, address, valid FROM tblorder WHERE uid = ? ORDER BY oid DESC";
				$stmt = $con->prepare($sql);
				$stmt->bind_param("i", $_SESSION['uid']);
				$stmt->execute();
				$result = $stmt->get_result();

				if ($result->num_rows > 0) {
					echo "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">";
					echo "<tr>
							<th>ID <br> Pesanan</th>
							<th>Waktu</th>
							<th>Metode <br>Pembayaran</th>
							<th>Alamat <br>Pengiriman</th>
							<th>Total</th>
							<th>Validasi</th>
							<th>Opsi</th>
						</tr>";

					while ($row = $result->fetch_assoc()) {
						echo "<tr>";
						echo "<td>" . htmlspecialchars($row['oid'] ?? '') . "</td>";
						echo "<td>" . htmlspecialchars($row['time'] ?? '') . "</td>";

						// Modify the payment method display
						$payment_method_display = ($row['payment_method'] === 'Prepaid') ? 'Debit' : 'COD';
						echo "<td>" . htmlspecialchars($payment_method_display) . "</td>";

						echo "<td>" . htmlspecialchars($row['address'] ?? '') . "</td>";
						echo "<td>Rp. " . htmlspecialchars(number_format($row['price'], 0, ',', '.') ?? '') . "</td>";
						echo "<td>" . htmlspecialchars($row['valid'] ?? '') . "</td>";
						echo "<td><a href=\"orderitems.php?oid=" . $row['oid'] . "\">Lihat</a></td>";
						echo "</tr>";
					}
					echo "</table>";
				} else {
					echo "<p>Tidak ada pesanan!</p>";
				}


				// Helper function to get the product price
				function getItemPrice($pid)
				{
					global $con;
					$stmt = $con->prepare("SELECT price FROM tblproduct WHERE pid = ?");
					$stmt->bind_param("i", $pid);
					$stmt->execute();
					$result = $stmt->get_result();
					$row = $result->fetch_assoc();
					return $row['price'];
				}
				?>
			</div>
		</div>
		<div class="footer">
			<?php showFooter(); ?>
		</div>
	</div>
</body>

</html>