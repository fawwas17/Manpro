<!--
"Medika Store" adalah sebuah website e-commerce yang dikembangkan untuk keperluan akademis. Website ini merupakan contoh sederhana dari sebuah keranjang belanja dan mungkin mengandung kesalahan atau bug.

Didesain dan dikembangkan oleh Achmad Sirajul Fahmi. (c) 2024 Hak Cipta Dilindungi.
-->
<?php

include "core.php";
include "dbconnection.php";

//if user not logged in, redirect to home page
if (isset($_SESSION['uid'])) {
  header("Location: index.php");
}

?>
<!DOCTYPE html
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Daftar</title>
  <link href="styles/style.css" rel="stylesheet" type="text/css" />
  <script src="js/myscript.js" language="javascript" type="text/javascript"></script>
</head>

<body>
  <div class="page">
    <div class="header">
      <?php

      showHeading();

      ?>
    </div>
    <div class="wrapper">
      <div class="navigation">
        <?php

        mainMenu();

        ?>
      </div>
      <div class="contents">
        <h2>Daftar</h2>
        <?php

        if ($_SERVER['REQUEST_METHOD'] == "POST") {
          $username = validateInput($_POST['txtUsername']);
          $password = validateInput($_POST['txtPassword']);
          $retypePassword = validateInput($_POST['txtRetypePassword']);
          $email = validateInput($_POST['txtEmail']);
          $dateOfBirth = validateInput($_POST['txtDateOfBirth']);
          $gender = validateInput($_POST['txtGender']);
          $address = validateInput($_POST['txtAddress']);
          $city = validateInput($_POST['txtCity']);
          $contactNo = validateInput($_POST['txtContactNo']);
          if ($password == $retypePassword) {
            $hashed_password = md5($password);
            $stmt = $con->prepare("INSERT INTO tbluser (username, password, email, date_of_birth, gender, address, city, contact_no) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssss", $username, $hashed_password, $email, $dateOfBirth, $gender, $address, $city, $contactNo);
            if ($stmt->execute()) {
              echo "Pendaftaran berhasil!<br/>";
            } else {
              echo "Pendaftaran gagal<br/>";
            }
          } else {
            echo "Password tidak cocok<br/>";
          }
        }
        ?>
        <form id="form1" name="form1" method="post" action="register.php" onsubmit="return validateRegister()">
          <p>
            <label>Username:
              <br />
              <input name="txtUsername" type="text" id="txtUsername" />
            </label>
          </p>
          <p>
            <label>Password:
              <br />
              <input name="txtPassword" type="password" id="txtPassword" />
            </label>
          </p>
          <p>
            <label>Retype Password:
              <br />
              <input name="txtRetypePassword" type="password" id="txtRetypePassword" />
            </label>
          </p>
          <p>
            <label>E-mail:
              <br />
              <input name="txtEmail" type="text" id="txtEmail" />
            </label>
          </p>
          <p>
            <label>Date of Birth:
              <br />
              <input name="txtDateOfBirth" type="date" id="txtDateOfBirth" />
            </label>
          </p>
          <p>
            <label>Gender:
              <br />
              <input type="radio" name="txtGender" value="male" /> Male
              <input type="radio" name="txtGender" value="female" /> Female
            </label>
          </p>
          <p>
            <label>Address:
              <br />
              <input name="txtAddress" type="text" id="txtAddress" />
            </label>
          </p>
          <p>
            <label>City:
              <br />
              <select name="txtCity" id="txtCity">
                <option value=" Jakarta">Jakarta</option>
                <option value="Bandung">Bandung</option>
                <option value="Surabaya">Surabaya</option>
                <option value="Yogyakarta">Yogyakarta</option>
                <option value="Lain-lain">Lain-lain</option>
              </select>
            </label>
          </p>
          <p>
            <label>Contact No:
              <br />
              <input name="txtContactNo" type="text" id="txtContactNo" />
            </label>
          </p>
          <p>
            <input type="submit" name="Submit" value="Daftar" />
            <input type="reset" name="Clear" value="Clear" />
          </p>
        </form>
      </div>
    </div>
    <div class="footer">
      <?php

      showFooter();

      ?>
    </div>
  </div>
</body>

</html>