<!DOCTYPE HTML>
<html>

<head>
  <title>spoerts Academy</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
    <link rel="stylesheet" href="style2.css" />  
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1><a href="store.php">Techno<span class="logo_colour">Geeks</span></a></h1>
          <h2>For all your tech needs and info</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <li><a href="store.php">Home</a></li>
          <li><a href="Get Involved.php">Get Involved</a></li>
          <li class="selected"><a href="Our Work.php">Our Work</a></li>
          <li><a href="About Us.php">About Us</a></li>
          <li><a href="contact.php">Contact Us</a></li>
		  <li><a href="Gallery.php">Gallery</a></li>
        </ul>
      </div>
    </div>
    <div id="site_content">
      <div class="sidebar">
        <h1>Fun Fact </h1>
        
        <p>Robots will take over the world some day.<br /><a href="https://www.thesouthafrican.com/news/">Read more</a></p>
        <h1>Connect With Us</h1>
        <ul>
          <li><a href="https://www.facebook.com/">Facebook</a></li>
          <li><a href="https://www.twitter.com/">Twitter</a></li>
          <li><a href="https://www.google.com/">Google</a></li>
          <li><a href="https://www.instagram.com/">Instagram</a></li>
        </ul>
        <h1>Search</h1>
        <form method="post" action="https://www.google.com/" id="search_form">
          <p>
            <input class="search" type="text" name="search_field" value="" />
            <input name="search" type="image" style="border: 0; margin: 0 0 -9px 5px;" src="style/search.png" alt="Search" title="Search" />
          </p>
        </form>
      </div>
      <div id="content">
        <h1>Our Work</h1>
		  <img class="pic" src="images/tech8.jpg" width="300" height="190" alt="" />	
		  <p>Our most recent project is the development of<br>
		  a robot who will aid in the study of different plant materials<br>
		  that will help doctors and farmers perform at a higher level <br>
		  but the robot will not be limited to those tasks only  <br>
		  further development has endless possibility <br> 
		  nd when all is said and done you know where to come <br> 
		  <br> 
		  <br>
		  </p>
		  
		    <img class="pic" src="images/tech7.jpg" width="300" height="190" alt="" />
		    <p>Everything requires energy <br> 
			and we here at TechnoGeeks are also developing new ways to <br> 
			generate a cleaner and safe way of energy generation <br>
			</p>
			
			<img class="pic" src="images/pick3.jpg" width="300" height="190" alt="" />
			<p>GAMING!!! <br>
			we are major game fanatics here at TechnoGeeks not just that but we are currently<br>
			in development of a fresh and new FPS type game....we cant wait to put it into production</p>
			
			<img class="pic" src="images/tech3.jpg" width="300" height="190" alt="" />
			<p>We do not develop smartphones <br>
			but we do give you the latest updates <br>
			on your favourite brands and more</p>
		  
		   
		   <img class="pic" src="images/tech9.jpg" width="300" height="190" alt="" />	
		   <p>We have an academy that teaches youth how to code<br>
       our aim here is to increase independence and decrease poverty <br/>
       we are more than just fun and games </p>
      </div>
    </div>
    <div id="footer">
      <p><a href="home.php">Home</a> | <a href="Our Work.php">Our Work</a> | <a href="About Us.php">About Us</a> | <a href="Get Involved.php">Get Involved</a> | <a href="contact.php">Contact Us</a></p>
      <p>Copyright &copy; Mihlali Solwandle</p>
    </div>
  </div>
</body>
</html>
