<?php
class Item{
	public $id;
	public $name;
	public $price;
	public $quantity;
}
?>